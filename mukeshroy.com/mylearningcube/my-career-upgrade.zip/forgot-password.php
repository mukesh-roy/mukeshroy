<a class="close-reveal-modal">&#215;</a>
<form method="post" action="index.php">
    <fieldset>
        <legend>Registered Email Address:</legend>
        <label for="f_email">Email<span class="red">*</span>:</label>
        <input type="text" id="f_email">

        <label for="u_password">Password<span class="mandatory">*</span>:</label>
        <input type="password" id="u_password">

        <input type="submit" class="button tiny radius" value="Submit">

        <div class="text-center">New to My Career Upgrae? <a href="javascript:void(0);">Register</a></div>
    </fieldset>
</form>
