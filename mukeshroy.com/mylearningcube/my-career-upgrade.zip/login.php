<a class="close-reveal-modal">&#215;</a>
<form method="post" action="index.php">
    <fieldset>
        <legend>Sign in via E-mail</legend>
        <label for="u_email">Email<span class="red">*</span>:</label>
        <input type="text" id="u_email">

        <label for="u_password">Password<span class="mandatory">*</span>:</label>
        <input type="password" id="u_password">

        <input type="submit" class="button tiny radius" value="Login">

        <div class="text-center">
            <a href="javascript:void(0);" data-reveal-id="myModal" data-reveal-ajax="forgot-password.php" data-reveal-ajax="true">Forgot password?</a> | <a
                href="javascript:void(0);">Resend activation
                link</a><br><br>
            New to My Career Upgrae? <a href="javascript:void(0);">Register</a>
        </div>
    </fieldset>
</form>

<form method="post" action="index.php">
    <fieldset>
        <legend>Registered Email Address:</legend>
        <label for="f_email">Email<span class="red">*</span>:</label>
        <input type="text" id="f_email">

        <label for="u_password">Password<span class="mandatory">*</span>:</label>
        <input type="password" id="u_password">

        <input type="submit" class="button tiny radius" value="Submit">

        <div class="text-center">New to My Career Upgrae? <a href="javascript:void(0);">Register</a></div>
    </fieldset>
</form><form method="post" action="index.php">
    <fieldset>
        <legend>Registered Email Address:</legend>
        <label for="f_email">Email<span class="red">*</span>:</label>
        <input type="text" id="f_email">

        <label for="u_password">Password<span class="mandatory">*</span>:</label>
        <input type="password" id="u_password">

        <input type="submit" class="button tiny radius" value="Submit">

        <div class="text-center">New to My Career Upgrae? <a href="javascript:void(0);">Register</a></div>
    </fieldset>
</form>
