<?php require_once 'header.php'; ?>



    <div class="row clearfix">
        <div class="large-12 column">
            <h5>Thanks for your order...</h5>
        </div>

        <div class="large-12 column">
            <div class="sober-bg text-center pt-20">
             We have received your order no is : <span id="order-id">#00000</span>, now you can access you course
            <a href="products.php" class="button small radius">Go to Your Purchased course</a>
            </div>
        </div>

    </div>
<?php require_once 'footer.php'; ?>
