<a class="close-reveal-modal">&#215;</a>

<div class="large-3 column pd-0">
    <img src="images/product-1.png" alt="product">
</div>
<div class="large-9 column">
    <h5 class="mg-0">Project Management Professional PMPBOK5 Classroom Training</h5>
    <h6>Course brief</h6>
    <ul>
        <li>Project Management Bible by Rita Mulcahy.</li>
        <li>Training on 40 plus case studies.</li>
        <li>Complete understanding of PMP certification procedure and Handholding/Guidance.</li>
        <li>All Students Get Access to Hundreds of Practice Questions to help you prepare for the PMP® Examination
            conducted b ...
        </li>
    </ul>
    <h6 class="mg-0">Course by</h6>
    My Career Upgrae Services Pte. Ltd.
    <a href="javascript:void(0);" class="button small radius">View Details</a>
</div>
