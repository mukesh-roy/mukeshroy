
<script src="js/app.min.js"></script>
<script src="js/datepicker.js"></script>
<script src="js/app.js"></script>
</body>
</html>
