<?php require_once 'header.php'; ?>



    <div class="row">
        <div class="large-12 column">
            <h5>Page not found</h5>
        </div>

            <div class="large-9 column pt-20">
                Error 404!<br>
                The page you were looking for appears to have been moved, deleted or does not exist. You could go back to
                where you were or head straight to our <a href="index.php">home page</a>
            </div>
            <div class="large-3 column text-center"><span class="sprite icon-404 grayscale-recover"></span></div>


    </div>
<?php require_once 'footer.php'; ?>
