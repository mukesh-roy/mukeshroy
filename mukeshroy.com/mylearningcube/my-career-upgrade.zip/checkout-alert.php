<?php require_once 'header.php'; ?>



    <div class="row clearfix">
        <div class="large-12 column">
            <h5 class="alert-box alert">Your Payment is not completed...</h5>
        </div>

        <div class="large-12 column">
            <div class="sober-bg text-center pt-20">
                Due to some technical resion your payment is not completed, Please write an email to <br>
                <a href="mailto:admin@bhavyam.net">admin@bhavyam.net</a><br><br>
                <a href="products.php" class="button small radius">Try Again to Purchase the course</a>
            </div>
        </div>

    </div>
<?php require_once 'footer.php'; ?>
