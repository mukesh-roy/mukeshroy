<a class="close-reveal-modal">&#215;</a>
<h4>CHANGE LOCATION</h4>
<div class="content-section">
    <div class="form-search">
        <form method="post" action="index.php" class="mg-0">
            <fieldset class="relative">
                <legend>Set Your Country</legend>
                <select>
                    <option value="-1" selected="">Select Country</option>
                    <option value="34">United States</option>
                    <option value="2">Australia</option>
                </select>
                <input class="button tiny radius mg-0" value="Go" type="submit">
            </fieldset>
        </form>
    </div>
</div>
